import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'YaClockComponent',
  templateUrl: './ya-clock.component.html',
  styleUrls: ['./ya-clock.component.css']
})
export class YaClockComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
