import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';

@Component({
  selector: 'ClockComponent',
  templateUrl: './clock.component.html',
  styleUrls: ['./clock.component.css']
})
export class ClockComponent implements OnInit {

  private clock: Observable<number>;
  private seconds: number;

  ngOnInit() {
    this.clock = new Observable(observer => {
      setInterval(() => {
        let newDate = new Date();
        observer.next(newDate.getSeconds());
      }, 1000);
    });

    const clockSubscription = this.clock.subscribe(
      secs => {
        this.seconds = secs;
        if (this.seconds === 45 ) {
          clockSubscription.unsubscribe();
        };
      });
  }

}
